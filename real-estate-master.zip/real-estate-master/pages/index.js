// 4 types de fonctions, soit GET, soit POST, soit PUT, soit DELETE
//GET : on récupère des données
//POST : on poste des données (on les crées)
//PUT : on poste aussi des données (mis à jour des données)
//DELETE : on supprime des données